CREATE DATABASE IF NOT EXISTS room_allocation
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE room_allocation;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(254) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('student', 'warden', 'admin') NOT NULL DEFAULT 'student',
  fee_cleared BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS warden_invites (
  email VARCHAR(254) NOT NULL PRIMARY KEY,
  role ENUM('warden', 'admin') NOT NULL,
  used BOOLEAN NOT NULL DEFAULT FALSE,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_invite_creator FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS rooms (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  block ENUM('Block A', 'Block B', 'Block C') NOT NULL,
  room_number VARCHAR(20) NOT NULL,
  capacity TINYINT UNSIGNED NOT NULL,
  occupied TINYINT UNSIGNED NOT NULL DEFAULT 0,
  UNIQUE KEY uq_room_block_number (block, room_number),
  CONSTRAINT chk_room_capacity CHECK (capacity BETWEEN 1 AND 20),
  CONSTRAINT chk_room_occupancy CHECK (occupied <= capacity)
);

CREATE TABLE IF NOT EXISTS applications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  student_id BIGINT UNSIGNED NOT NULL,
  student_email VARCHAR(254) NOT NULL,
  block ENUM('Block A', 'Block B', 'Block C') NOT NULL,
  room_type ENUM('Single', 'Double', 'Triple') NOT NULL,
  document_path VARCHAR(255) NOT NULL,
  status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  assigned_room VARCHAR(20) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_application_student_status (student_id, status),
  KEY idx_application_status_created (status, created_at),
  CONSTRAINT fk_application_student FOREIGN KEY (student_id) REFERENCES users(id)
);