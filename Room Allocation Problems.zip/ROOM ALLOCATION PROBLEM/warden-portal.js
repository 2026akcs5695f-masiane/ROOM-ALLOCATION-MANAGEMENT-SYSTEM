// Warden portal: role-gated access, application decisions, and room inventory.
const wardenMessage = document.querySelector("#warden-message");
const loginSection = document.querySelector("#warden-login-section");
const dashboard = document.querySelector("#warden-dashboard");
const logoutButton = document.querySelector("#warden-logout-button");
const pendingApplications = document.querySelector("#pending-applications");
const occupancySummary = document.querySelector("#occupancy-summary");
const inviteManagementSection = document.querySelector("#invite-management-section");
const inviteRoleField = document.querySelector("#invite-role-field");
const inviteRoleSelect = document.querySelector("#invite-role");
const inviteResult = document.querySelector("#warden-invite-result");
const staffDashboardTitle = document.querySelector("#staff-dashboard-title");
const staffDashboardDescription = document.querySelector("#staff-dashboard-description");
const staffRoleBadge = document.querySelector("#staff-role-badge");
const staffNextStepLabel = document.querySelector("#staff-next-step-label");
const staffNextStepTitle = document.querySelector("#staff-next-step-title");
const staffNextStepCopy = document.querySelector("#staff-next-step-copy");
const inviteSectionTitle = document.querySelector("#invite-section-title");
const inviteSectionCopy = document.querySelector("#invite-section-copy");
const inviteEmailLabel = document.querySelector("#invite-email-label");
const wardenLoginForm = document.querySelector("#warden-login-form");
const wardenRegisterForm = document.querySelector("#warden-register-form");

let currentWarden = null;
let currentWardenRole = "";
let activeMessageTimer = null;
let refreshTimer = null;

async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", ...options });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Something went wrong. Please try again.");
  return result;
}

function showMessage(text, kind = "success", keepVisible = false) {
  window.clearTimeout(activeMessageTimer);
  wardenMessage.textContent = text;
  wardenMessage.className = `message message-${kind}`;
  if (!keepVisible) activeMessageTimer = window.setTimeout(() => wardenMessage.classList.add("hidden"), 7000);
}

function showLogin() {
  currentWarden = null;
  currentWardenRole = "";
  window.clearInterval(refreshTimer);
  refreshTimer = null;
  staffDashboardTitle.textContent = "Staff sign in";
  staffDashboardDescription.textContent = "Sign in as a warden or administrator. Your account role determines which staff tools are available.";
  staffRoleBadge.classList.add("hidden");
  loginSection.classList.remove("hidden");
  dashboard.classList.add("hidden");
  logoutButton.classList.add("hidden");
  inviteManagementSection.classList.add("hidden");
  wardenLoginForm.classList.remove("hidden");
  wardenRegisterForm.classList.add("hidden");
}

document.querySelector("#show-warden-register").addEventListener("click", () => {
  wardenLoginForm.classList.add("hidden");
  wardenRegisterForm.classList.remove("hidden");
  document.querySelector("#new-warden-email").focus();
});

document.querySelector("#show-warden-login").addEventListener("click", () => {
  wardenRegisterForm.classList.add("hidden");
  wardenLoginForm.classList.remove("hidden");
  document.querySelector("#warden-email").focus();
});

function addCell(row, value) {
  const cell = document.createElement("td");
  cell.textContent = value;
  row.append(cell);
  return cell;
}

function makeEmptyState(text) {
  const paragraph = document.createElement("p");
  paragraph.className = "empty-state";
  paragraph.textContent = text;
  return paragraph;
}

function makeButton(label, className, onClick) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `button ${className} button-small`;
  button.textContent = label;
  button.addEventListener("click", onClick);
  return button;
}

async function refreshPendingApplications() {
  if (!currentWarden) return;
  try {
    const { applications } = await api("/api/warden/applications");
    pendingApplications.replaceChildren();
    if (!applications.length) {
      pendingApplications.append(makeEmptyState("There are no pending applications."));
      return;
    }
    const table = document.createElement("table");
    table.className = "data-table warden-table";
    const head = document.createElement("thead");
    const headerRow = document.createElement("tr");
    for (const heading of ["Student email", "Block", "Room type", "Document", "Decision"]) {
      const header = document.createElement("th");
      header.scope = "col";
      header.textContent = heading;
      headerRow.append(header);
    }
    head.append(headerRow);
    const body = document.createElement("tbody");
    for (const application of applications) {
      const row = document.createElement("tr");
      addCell(row, application.studentEmail || "Unknown student");
      addCell(row, application.block || "");
      addCell(row, application.roomType || "");
      const documentCell = document.createElement("td");
      const documentLink = document.createElement("a");
      documentLink.href = application.documentUrl;
      documentLink.target = "_blank";
      documentLink.rel = "noopener noreferrer";
      documentLink.textContent = "Open document";
      documentCell.append(documentLink);
      row.append(documentCell);
      const actionsCell = document.createElement("td");
      actionsCell.className = "action-cell";
      actionsCell.append(
        makeButton("Approve", "button-primary", () => reviewApplication(application, "approve")),
        makeButton("Reject", "button-danger", () => reviewApplication(application, "reject"))
      );
      row.append(actionsCell);
      body.append(row);
    }
    table.append(head, body);
    pendingApplications.append(table);
  } catch (error) {
    showMessage(`Could not load applications: ${error.message}`, "error", true);
  }
}

async function refreshOccupancy() {
  if (!currentWarden) return;
  try {
    const { rooms } = await api("/api/rooms");
    occupancySummary.replaceChildren();
    const totals = new Map();
    for (const room of rooms) {
      const value = totals.get(room.block) || { capacity: 0, occupied: 0 };
      value.capacity += Number(room.capacity);
      value.occupied += Number(room.occupied);
      totals.set(room.block, value);
    }
    if (!totals.size) {
      occupancySummary.append(makeEmptyState("Add rooms to see occupancy totals."));
      return;
    }
    for (const [block, value] of [...totals.entries()].sort(([first], [second]) => first.localeCompare(second))) {
      const summary = document.createElement("article");
      summary.className = "summary-item";
      const heading = document.createElement("h3");
      heading.textContent = block;
      const values = document.createElement("p");
      values.textContent = `${value.occupied} occupied · ${value.capacity} total · ${Math.max(0, value.capacity - value.occupied)} available`;
      summary.append(heading, values);
      occupancySummary.append(summary);
    }
  } catch (error) {
    showMessage(`Could not load room summary: ${error.message}`, "error", true);
  }
}

async function refreshDashboard() {
  await Promise.all([refreshPendingApplications(), refreshOccupancy()]);
}

async function reviewApplication(application, action) {
  try {
    const result = await api(`/api/warden/applications/${encodeURIComponent(application.id)}/${action}`, { method: "POST" });
    showMessage(action === "approve" ? `Application approved and assigned to room ${result.assignedRoom}.` : "Application rejected.");
    await refreshDashboard();
  } catch (error) {
    showMessage(`Could not ${action} application: ${error.message}`, "error", true);
  }
}

async function signIn(form) {
  const formData = new FormData(form);
  try {
    const { user } = await api("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: formData.get("email"), password: formData.get("password") })
    });
    form.reset();
    await openDashboard(user);
  } catch (error) {
    form.querySelector('[name="password"]').value = "";
    showMessage(error.message, "error", true);
  }
}

async function openDashboard(user) {
  if (user.role === "student") {
    try {
      ({ user } = await api("/api/warden/claim", { method: "POST" }));
    } catch {
      window.location.assign("/index.html");
      return;
    }
  }
  if (!["warden", "admin"].includes(user.role)) {
    showLogin();
    showMessage("Access denied. This account is not a warden or admin.", "error", true);
    return;
  }
  currentWarden = user;
  currentWardenRole = user.role;
  const isAdmin = user.role === "admin";
  staffDashboardTitle.textContent = isAdmin ? "Administrator dashboard" : "Warden operations dashboard";
  staffDashboardDescription.textContent = isAdmin
    ? "Manage staff access, review applications, and oversee hostel room capacity."
    : "Review student applications, manage rooms, and monitor hostel capacity.";
  staffRoleBadge.textContent = isAdmin ? "ADMINISTRATOR · FULL ACCESS" : "WARDEN · OPERATIONS";
  staffRoleBadge.classList.toggle("role-badge-admin", isAdmin);
  staffRoleBadge.classList.toggle("role-badge-warden", !isAdmin);
  staffRoleBadge.classList.remove("hidden");
  staffNextStepLabel.textContent = isAdmin ? "ADMINISTRATOR NEXT STEPS" : "WARDEN NEXT STEPS";
  staffNextStepTitle.textContent = isAdmin ? "Manage hostel operations and staff" : "Set up your warden workspace";
  staffNextStepCopy.textContent = isAdmin
    ? "Invite staff with the correct role, then oversee room inventory and student application decisions."
    : "Add room capacity first, then review student applications. You can invite more wardens once you are ready.";
  inviteSectionTitle.textContent = isAdmin ? "Manage staff invitations" : "Invite a warden";
  inviteSectionCopy.textContent = isAdmin
    ? "Assign each new staff account the correct role. Administrators can invite wardens or other administrators."
    : "Wardens can invite other wardens. Administrator access can only be granted by an administrator.";
  inviteEmailLabel.textContent = isAdmin ? "Staff email" : "Warden email";
  loginSection.classList.add("hidden");
  dashboard.classList.remove("hidden");
  logoutButton.classList.remove("hidden");
  inviteManagementSection.classList.remove("hidden");
  inviteRoleField.classList.toggle("hidden", user.role !== "admin");
  inviteRoleSelect.disabled = user.role !== "admin";
  await refreshDashboard();
  window.clearInterval(refreshTimer);
  refreshTimer = window.setInterval(refreshDashboard, 8000);
  if (new URLSearchParams(window.location.search).has("welcome")) {
    showMessage(isAdmin
      ? "Your administrator account is ready. Use staff invitations to assign roles, then review hostel operations."
      : "Your warden account is ready. Start by adding a room, then review student applications.");
    window.history.replaceState({}, "", window.location.pathname);
  }
}

wardenLoginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  signIn(event.currentTarget);
});

wardenRegisterForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  try {
    const { user } = await api("/api/warden/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: formData.get("email"), password: formData.get("password") })
    });
    form.reset();
    await openDashboard(user);
    if (user.role === "warden") showMessage("Your warden account is ready. Start by adding a room, then review student applications.");
  } catch (error) {
    form.querySelector('[name="password"]').value = "";
    showMessage(error.message, "error", true);
  }
});

document.querySelector("#warden-invite-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const email = String(formData.get("email")).trim().toLowerCase();
  try {
    await api("/api/warden/invites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, role: currentWardenRole === "admin" ? formData.get("role") : "warden" })
    });
    form.reset();
    inviteResult.textContent = `Invitation created for ${email}. They can register here using this exact email.`;
    inviteResult.classList.remove("hidden");
    showMessage("Warden invitation created.");
  } catch (error) {
    showMessage(`Could not create invitation: ${error.message}`, "error", true);
  }
});

document.querySelector("#add-room-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const roomNumber = formData.get("roomNumber");
  try {
    await api("/api/warden/rooms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ block: formData.get("block"), roomNumber, capacity: formData.get("capacity") })
    });
    form.reset();
    await refreshOccupancy();
    showMessage(`Room ${roomNumber} added.`);
  } catch (error) {
    showMessage(`Could not add room: ${error.message}`, "error", true);
  }
});

logoutButton.addEventListener("click", async () => {
  try {
    await api("/api/auth/logout", { method: "POST" });
    showLogin();
    showMessage("You have logged out.");
  } catch (error) {
    showMessage(`Could not log out: ${error.message}`, "error", true);
  }
});

api("/api/auth/me")
  .then(({ user }) => { if (user) return openDashboard(user); })
  .catch((error) => showMessage(`Could not connect to the prototype server: ${error.message}`, "error", true));
