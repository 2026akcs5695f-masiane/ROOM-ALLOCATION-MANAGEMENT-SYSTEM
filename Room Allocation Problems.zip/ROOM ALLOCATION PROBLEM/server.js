require("dotenv").config();

const bcrypt = require("bcryptjs");
const express = require("express");
const session = require("express-session");
const multer = require("multer");
const mysql = require("mysql2/promise");
const fs = require("node:fs/promises");
const path = require("node:path");
const { promisify } = require("node:util");

const app = express();
const root = __dirname;
const documentDirectory = path.join(root, "uploads", "documents");
const allowedBlocks = ["Block A", "Block B", "Block C"];
const allowedRoomTypes = ["Single", "Double", "Triple"];
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const database = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "room_allocation",
  waitForConnections: true,
  connectionLimit: 10,
  decimalNumbers: true
});

const upload = multer({
  storage: multer.diskStorage({
    destination: async (_request, _file, callback) => {
      try {
        await fs.mkdir(documentDirectory, { recursive: true });
        callback(null, documentDirectory);
      } catch (error) {
        callback(error);
      }
    },
    filename: (_request, file, callback) => {
      const extensions = {
        "application/pdf": ".pdf",
        "image/png": ".png",
        "image/jpeg": ".jpg"
      };
      callback(null, `${require("node:crypto").randomUUID()}${extensions[file.mimetype] || ""}`);
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  fileFilter: (_request, file, callback) => {
    if (!["application/pdf", "image/png", "image/jpeg"].includes(file.mimetype)) {
      callback(new Error("Choose a PDF, PNG, or JPG file."));
      return;
    }
    callback(null, true);
  }
});

app.use(express.json({ limit: "32kb" }));
app.use(session({
  name: "room-allocation-session",
  secret: process.env.SESSION_SECRET || "local-prototype-session-secret-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: false, maxAge: 8 * 60 * 60 * 1000 }
}));

function asyncRoute(handler) {
  return (request, response, next) => Promise.resolve(handler(request, response, next)).catch(next);
}

function requireUser(request, response, next) {
  if (!request.session.user) return response.status(401).json({ error: "Log in to continue." });
  next();
}

function requireStaff(request, response, next) {
  if (!request.session.user || !["warden", "admin"].includes(request.session.user.role)) {
    return response.status(403).json({ error: "Warden access is required." });
  }
  next();
}

function validCredentials(email, password) {
  return typeof email === "string" && emailPattern.test(email.trim())
    && typeof password === "string" && password.length >= 6;
}

function sessionLogin(request, user) {
  return promisify(request.session.regenerate).call(request.session).then(() => {
    request.session.user = { id: user.id, email: user.email, role: user.role };
  });
}

function publicApplication(row) {
  return {
    id: String(row.id),
    studentEmail: row.student_email,
    block: row.block,
    roomType: row.room_type,
    status: row.status,
    assignedRoom: row.assigned_room,
    createdAt: row.created_at,
    documentUrl: `/api/warden/applications/${row.id}/document`
  };
}

app.get("/", (_request, response) => response.sendFile(path.join(root, "index.html")));
app.get(["/index.html", "/warden.html", "/style.css", "/student-portal.js", "/warden-portal.js", "/university-logo.png"], (request, response, next) => {
  const requestedFile = path.join(root, path.basename(request.path));
  response.sendFile(requestedFile, (error) => { if (error) next(error); });
});

app.get("/api/auth/me", (request, response) => response.json({ user: request.session.user || null }));

app.post("/api/auth/register", asyncRoute(async (request, response) => {
  const email = String(request.body.email || "").trim().toLowerCase();
  const password = request.body.password;
  const requestedRole = request.body.role || "student";
  if (!validCredentials(email, password)) return response.status(400).json({ error: "Enter a valid email and a password with at least 6 characters." });
  if (!["student", "warden"].includes(requestedRole)) return response.status(400).json({ error: "Choose either student or warden registration." });
  const bootstrapEmail = String(process.env.BOOTSTRAP_ADMIN_EMAIL || "").trim().toLowerCase();
  const role = requestedRole === "warden" && email === bootstrapEmail ? "admin" : requestedRole;

  const passwordHash = await bcrypt.hash(password, 10);
  try {
    const [result] = await database.execute(
      "INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)",
      [email, passwordHash, role]
    );
    const user = { id: result.insertId, email, role };
    await sessionLogin(request, user);
    response.status(201).json({ user });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") return response.status(409).json({ error: "That email already has an account. Try logging in." });
    throw error;
  }
}));

app.post("/api/auth/login", asyncRoute(async (request, response) => {
  const email = String(request.body.email || "").trim().toLowerCase();
  const password = request.body.password;
  const [rows] = await database.execute("SELECT id, email, password_hash, role FROM users WHERE email = ?", [email]);
  if (!rows.length || typeof password !== "string" || !await bcrypt.compare(password, rows[0].password_hash)) {
    return response.status(401).json({ error: "The email or password is incorrect." });
  }
  const user = { id: rows[0].id, email: rows[0].email, role: rows[0].role };
  await sessionLogin(request, user);
  response.json({ user });
}));

app.post("/api/auth/logout", (request, response, next) => {
  request.session.destroy((error) => {
    if (error) return next(error);
    response.clearCookie("room-allocation-session", { httpOnly: true, sameSite: "strict" });
    response.json({ ok: true });
  });
});

app.get("/api/rooms", requireUser, asyncRoute(async (_request, response) => {
  const [rows] = await database.execute("SELECT block, room_number AS roomNumber, capacity, occupied FROM rooms ORDER BY block, room_number");
  response.json({ rooms: rows });
}));

app.get("/api/applications/mine", requireUser, asyncRoute(async (request, response) => {
  const [rows] = await database.execute(
    "SELECT id, student_email, block, room_type, status, assigned_room, created_at FROM applications WHERE student_id = ? ORDER BY created_at DESC",
    [request.session.user.id]
  );
  response.json({ applications: rows.map(publicApplication) });
}));

app.post("/api/applications", requireUser, upload.single("document"), asyncRoute(async (request, response) => {
  const removeUpload = async () => { if (request.file) await fs.unlink(request.file.path).catch(() => {}); };
  const { block, roomType } = request.body;
  if (request.session.user.role !== "student") {
    await removeUpload();
    return response.status(403).json({ error: "Only student accounts can apply for a room." });
  }
  if (!request.file || !allowedBlocks.includes(block) || !allowedRoomTypes.includes(roomType)) {
    await removeUpload();
    return response.status(400).json({ error: "Choose a block, room type, and supporting document." });
  }

  const connection = await database.getConnection();
  try {
    await connection.beginTransaction();
    await connection.execute("SELECT id FROM users WHERE id = ? FOR UPDATE", [request.session.user.id]);
    const [existing] = await connection.execute(
      "SELECT id FROM applications WHERE student_id = ? AND status IN ('pending', 'approved') LIMIT 1",
      [request.session.user.id]
    );
    if (existing.length) {
      await connection.rollback();
      await removeUpload();
      return response.status(409).json({ error: "You already have a pending or approved application." });
    }
    const [result] = await connection.execute(
      "INSERT INTO applications (student_id, student_email, block, room_type, document_path) VALUES (?, ?, ?, ?, ?)",
      [request.session.user.id, request.session.user.email, block, roomType, request.file.filename]
    );
    await connection.commit();
    response.status(201).json({ id: String(result.insertId) });
  } catch (error) {
    await connection.rollback();
    await removeUpload();
    throw error;
  } finally {
    connection.release();
  }
}));

app.post("/api/warden/register", asyncRoute(async (request, response) => {
  const email = String(request.body.email || "").trim().toLowerCase();
  const password = request.body.password;
  if (!validCredentials(email, password)) return response.status(400).json({ error: "Enter a valid email and a password with at least 6 characters." });

  const connection = await database.getConnection();
  try {
    await connection.beginTransaction();
    const [invites] = await connection.execute("SELECT role, used FROM warden_invites WHERE email = ? FOR UPDATE", [email]);
    const bootstrapEmail = String(process.env.BOOTSTRAP_ADMIN_EMAIL || "").trim().toLowerCase();
    let role = bootstrapEmail && email === bootstrapEmail ? "admin" : "warden";
    if (invites.length && !invites[0].used) role = invites[0].role;
    const passwordHash = await bcrypt.hash(password, 10);
    const [result] = await connection.execute(
      "INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)",
      [email, passwordHash, role]
    );
    if (invites.length && !invites[0].used) await connection.execute("UPDATE warden_invites SET used = TRUE WHERE email = ?", [email]);
    await connection.commit();
    const user = { id: result.insertId, email, role };
    await sessionLogin(request, user);
    response.status(201).json({ user });
  } catch (error) {
    await connection.rollback();
    if (error.code === "ER_DUP_ENTRY") return response.status(409).json({ error: "This email already has an account. Log in to claim the invitation." });
    throw error;
  } finally {
    connection.release();
  }
}));

app.post("/api/warden/claim", requireUser, asyncRoute(async (request, response) => {
  const connection = await database.getConnection();
  try {
    await connection.beginTransaction();
    const email = request.session.user.email;
    const [invites] = await connection.execute("SELECT role, used FROM warden_invites WHERE email = ? FOR UPDATE", [email]);
    let role = "";
    if (invites.length && !invites[0].used) role = invites[0].role;
    else if (email === String(process.env.BOOTSTRAP_ADMIN_EMAIL || "").trim().toLowerCase()) role = "admin";
    if (request.session.user.role !== "student" || !role) {
      await connection.rollback();
      return response.status(403).json({ error: "This account has no active warden invitation." });
    }
    await connection.execute("UPDATE users SET role = ? WHERE id = ?", [role, request.session.user.id]);
    if (invites.length) await connection.execute("UPDATE warden_invites SET used = TRUE WHERE email = ?", [email]);
    await connection.commit();
    request.session.user.role = role;
    response.json({ user: request.session.user });
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}));

app.post("/api/warden/invites", requireStaff, asyncRoute(async (request, response) => {
  const email = String(request.body.email || "").trim().toLowerCase();
  const role = request.session.user.role === "admin" && request.body.role === "admin" ? "admin" : "warden";
  if (!emailPattern.test(email)) return response.status(400).json({ error: "Enter a valid email address." });
  try {
    const [result] = await database.execute(
      "INSERT INTO warden_invites (email, role, created_by) VALUES (?, ?, ?)",
      [email, role, request.session.user.id]
    );
    response.status(201).json({ email, role, created: result.affectedRows === 1 });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") return response.status(409).json({ error: "An invitation already exists for this email." });
    throw error;
  }
}));

app.get("/api/warden/applications", requireStaff, asyncRoute(async (_request, response) => {
  const [rows] = await database.execute(
    "SELECT id, student_email, block, room_type, status, assigned_room, created_at FROM applications WHERE status = 'pending' ORDER BY created_at"
  );
  response.json({ applications: rows.map(publicApplication) });
}));

app.get("/api/warden/applications/:id/document", requireStaff, asyncRoute(async (request, response) => {
  const [rows] = await database.execute("SELECT document_path FROM applications WHERE id = ?", [request.params.id]);
  if (!rows.length) return response.status(404).json({ error: "Application not found." });
  response.sendFile(path.join(documentDirectory, path.basename(rows[0].document_path)));
}));

app.post("/api/warden/applications/:id/reject", requireStaff, asyncRoute(async (request, response) => {
  const [result] = await database.execute(
    "UPDATE applications SET status = 'rejected' WHERE id = ? AND status = 'pending'",
    [request.params.id]
  );
  if (!result.affectedRows) return response.status(409).json({ error: "This application has already been handled." });
  response.json({ ok: true });
}));

app.post("/api/warden/applications/:id/approve", requireStaff, asyncRoute(async (request, response) => {
  const connection = await database.getConnection();
  try {
    await connection.beginTransaction();
    const [applications] = await connection.execute(
      "SELECT id, block, status FROM applications WHERE id = ? FOR UPDATE",
      [request.params.id]
    );
    if (!applications.length || applications[0].status !== "pending") {
      await connection.rollback();
      return response.status(409).json({ error: "This application has already been handled." });
    }
    const application = applications[0];
    const [rooms] = await connection.execute(
      "SELECT id, room_number FROM rooms WHERE block = ? AND occupied < capacity ORDER BY room_number FOR UPDATE",
      [application.block]
    );
    if (!rooms.length) {
      await connection.rollback();
      return response.status(409).json({ error: `No spaces are available in ${application.block}.` });
    }
    const room = rooms[0];
    await connection.execute("UPDATE rooms SET occupied = occupied + 1 WHERE id = ?", [room.id]);
    await connection.execute(
      "UPDATE applications SET status = 'approved', assigned_room = ? WHERE id = ?",
      [room.room_number, application.id]
    );
    await connection.commit();
    response.json({ assignedRoom: room.room_number });
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}));

app.post("/api/warden/rooms", requireStaff, asyncRoute(async (request, response) => {
  const { block, roomNumber } = request.body;
  const capacity = Number(request.body.capacity);
  if (!allowedBlocks.includes(block) || typeof roomNumber !== "string" || !roomNumber.trim()
      || !Number.isInteger(capacity) || capacity < 1 || capacity > 20) {
    return response.status(400).json({ error: "Enter a block, room number, and capacity from 1 to 20." });
  }
  try {
    await database.execute(
      "INSERT INTO rooms (block, room_number, capacity) VALUES (?, ?, ?)",
      [block, roomNumber.trim(), capacity]
    );
    response.status(201).json({ ok: true });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") return response.status(409).json({ error: "That room already exists in this block." });
    throw error;
  }
}));

app.use((error, _request, response, _next) => {
  console.error(error);
  if (error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE") {
    return response.status(400).json({ error: "Choose a document no larger than 10 MB." });
  }
  if (error.message === "Choose a PDF, PNG, or JPG file.") return response.status(400).json({ error: error.message });
  response.status(500).json({ error: "The server could not complete that request." });
});

const port = Number(process.env.PORT || 3000);
database.getConnection()
  .then((connection) => connection.release())
  .then(() => app.listen(port, () => console.log(`Room allocation prototype: http://localhost:${port}`)))
  .catch((error) => {
    console.error("Could not connect to MySQL. Check your .env settings and import schema.sql.", error.message);
    process.exitCode = 1;
  });