# Kabale University Room Allocation Prototype

A small room-allocation prototype using HTML, CSS, vanilla JavaScript, an Express API, and MySQL. The browser pages communicate only with the local API; account passwords are hashed before storage.

## Requirements

- Node.js 18 or newer
- MySQL 8 or newer

## Run locally

1. Create the database tables by running `schema.sql` in MySQL Workbench, or from PowerShell:

   ```powershell
   Get-Content .\schema.sql | mysql -u root -p
   ```

2. Create the local environment file and install the server packages:

   ```powershell
   Copy-Item .env.example .env
   npm install
   ```

3. Edit `.env` with your MySQL password, a long random `SESSION_SECRET`, and the email address that will create the first admin account in `BOOTSTRAP_ADMIN_EMAIL`.

4. Start the server:

   ```powershell
   npm start
   ```

Open `http://localhost:3000`. The student registration form lets each person choose Student or Warden and opens the matching dashboard after registration. Warden registration is open for this prototype; only the email configured in `BOOTSTRAP_ADMIN_EMAIL` receives the admin role. Admins can invite other admins or wardens, and wardens can invite wardens.

## Prototype behavior

- MySQL stores users, staff invitations, rooms, and applications. Supporting documents are stored under `uploads/documents/` and are excluded from Git.
- Room and application views refresh every eight seconds. Approval and room occupancy updates run together in a MySQL transaction.
- Warden accounts can review applications and add rooms. Admins can invite either wardens or admins; wardens can invite wardens.
- Existing student accounts can claim a staff invitation by logging in through `warden.html` with the invited email.

This is for local demonstration only. Sessions use Express's in-memory store, email verification is not implemented, and uploads are local files. Do not expose the server publicly or use real student documents without adding production session storage, HTTPS, email verification, backups, and stricter operational controls.
