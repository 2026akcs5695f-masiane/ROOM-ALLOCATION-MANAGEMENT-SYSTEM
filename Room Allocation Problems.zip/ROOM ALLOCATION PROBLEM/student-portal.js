// Student portal: account access, applications, uploads, and room information.
const pageMessage = document.querySelector("#page-message");
const authSection = document.querySelector("#auth-section");
const studentDashboard = document.querySelector("#student-dashboard");
const logoutButton = document.querySelector("#logout-button");
const applicationForm = document.querySelector("#application-form");
const applicationLockMessage = document.querySelector("#application-lock-message");
const myApplications = document.querySelector("#my-applications");
const roomAvailability = document.querySelector("#room-availability");
const submitApplicationButton = document.querySelector("#submit-application");
const nextStepCopy = document.querySelector("#student-next-step-copy");
const nextStepLink = document.querySelector("#student-next-step-link");
const loginForm = document.querySelector("#login-form");
const registerForm = document.querySelector("#register-form");

let currentUser = null;
let activeMessageTimer = null;
let applicationRefreshTimer = null;
let roomRefreshTimer = null;

async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", ...options });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Something went wrong. Please try again.");
  return result;
}

function showMessage(text, kind = "success", keepVisible = false) {
  window.clearTimeout(activeMessageTimer);
  pageMessage.textContent = text;
  pageMessage.className = `message message-${kind}`;
  if (!keepVisible) activeMessageTimer = window.setTimeout(() => pageMessage.classList.add("hidden"), 7000);
}

function setSignedIn(user) {
  const signedIn = Boolean(user && user.role === "student");
  currentUser = signedIn ? user : null;
  authSection.classList.toggle("hidden", signedIn);
  studentDashboard.classList.toggle("hidden", !signedIn);
  logoutButton.classList.toggle("hidden", !signedIn);
  if (signedIn) {
    refreshApplications();
    refreshRooms();
    applicationRefreshTimer = window.setInterval(refreshApplications, 8000);
    roomRefreshTimer = window.setInterval(refreshRooms, 8000);
  } else {
    stopRefreshes();
  }
}

function stopRefreshes() {
  window.clearInterval(applicationRefreshTimer);
  window.clearInterval(roomRefreshTimer);
  applicationRefreshTimer = null;
  roomRefreshTimer = null;
}

function appendTextCell(row, value, className = "") {
  const cell = document.createElement("td");
  cell.textContent = value;
  if (className) cell.className = className;
  row.append(cell);
}

function makeEmptyState(text) {
  const paragraph = document.createElement("p");
  paragraph.className = "empty-state";
  paragraph.textContent = text;
  return paragraph;
}

async function refreshApplications() {
  if (!currentUser) return;
  try {
    const { applications } = await api("/api/applications/mine");
    myApplications.replaceChildren();
    const hasOpenApplication = applications.some((application) => ["pending", "approved"].includes(application.status));
    applicationForm.classList.toggle("hidden", hasOpenApplication);
    applicationLockMessage.classList.toggle("hidden", !hasOpenApplication);
    if (!applications.length) {
      nextStepCopy.textContent = "Start by submitting a room application with your preferred block, room type, and fee receipt or admission letter.";
      nextStepLink.href = "#application-section";
      nextStepLink.textContent = "Start an application";
    } else {
      const latestApplication = applications[0];
      const messages = {
        pending: "Your application is waiting for review. Check its status here while the warden reviews your request.",
        approved: `Your application is approved${latestApplication.assignedRoom ? ` and assigned to room ${latestApplication.assignedRoom}` : ""}. Check room availability for current hostel capacity.`,
        rejected: "Your last application was rejected. Review your details, then submit a new application when ready."
      };
      nextStepCopy.textContent = messages[latestApplication.status] || "Review your application status below.";
      nextStepLink.href = latestApplication.status === "rejected" ? "#application-section" : "#my-applications-section";
      nextStepLink.textContent = latestApplication.status === "rejected" ? "Apply again" : "View application status";
    }
    if (!applications.length) {
      myApplications.append(makeEmptyState("You have not submitted an application yet."));
      return;
    }
    for (const application of applications) {
      const item = document.createElement("article");
      item.className = "application-item";
      const details = document.createElement("div");
      const title = document.createElement("h3");
      title.textContent = `${application.block} · ${application.roomType}`;
      const room = document.createElement("p");
      room.className = "muted-copy";
      room.textContent = application.assignedRoom ? `Assigned room: ${application.assignedRoom}` : "No room assigned yet";
      details.append(title, room);
      const status = document.createElement("span");
      status.className = `status-badge status-${application.status}`;
      status.textContent = application.status || "unknown";
      item.append(details, status);
      myApplications.append(item);
    }
  } catch (error) {
    showMessage(`Could not load applications: ${error.message}`, "error", true);
  }
}

async function refreshRooms() {
  if (!currentUser) return;
  try {
    const { rooms } = await api("/api/rooms");
    roomAvailability.replaceChildren();
    if (!rooms.length) {
      roomAvailability.append(makeEmptyState("No rooms have been added yet."));
      return;
    }
    const table = document.createElement("table");
    table.className = "data-table";
    const head = document.createElement("thead");
    const headerRow = document.createElement("tr");
    for (const heading of ["Block", "Room", "Capacity", "Spaces left"]) {
      const cell = document.createElement("th");
      cell.scope = "col";
      cell.textContent = heading;
      headerRow.append(cell);
    }
    head.append(headerRow);
    const body = document.createElement("tbody");
    for (const room of rooms) {
      const left = Math.max(0, Number(room.capacity) - Number(room.occupied));
      const row = document.createElement("tr");
      appendTextCell(row, room.block);
      appendTextCell(row, room.roomNumber);
      appendTextCell(row, String(room.capacity));
      appendTextCell(row, left > 0 ? `${left} available` : "FULL", left > 0 ? "availability-open" : "availability-full");
      body.append(row);
    }
    table.append(head, body);
    roomAvailability.append(table);
  } catch (error) {
    showMessage(`Could not load room availability: ${error.message}`, "error", true);
  }
}

async function submitCredentials(form, endpoint, successMessage, role = "student") {
  const formData = new FormData(form);
  try {
    const { user } = await api(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: formData.get("email"), password: formData.get("password"), role })
    });
    if (["warden", "admin"].includes(user.role)) {
      window.location.assign("/warden.html?welcome=1");
      return;
    }
    form.reset();
    setSignedIn(user);
    showMessage(successMessage);
  } catch (error) {
    form.querySelector('[name="password"]').value = "";
    showMessage(error.message, "error", true);
  }
}

document.querySelector("#show-register").addEventListener("click", () => {
  loginForm.classList.add("hidden");
  registerForm.classList.remove("hidden");
  document.querySelector("#register-email").focus();
});

document.querySelector("#show-login").addEventListener("click", () => {
  registerForm.classList.add("hidden");
  loginForm.classList.remove("hidden");
  document.querySelector("#login-email").focus();
});

registerForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const role = new FormData(form).get("role");
  const endpoint = role === "warden" ? "/api/warden/register" : "/api/auth/register";
  submitCredentials(form, endpoint, "Your student account is ready. Start by submitting a room application below.", role);
});

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  submitCredentials(event.currentTarget, "/api/auth/login", "You are logged in.");
});

applicationForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!currentUser) return;
  const formData = new FormData(applicationForm);
  const file = formData.get("document");
  if (!(file instanceof File) || file.size === 0) {
    showMessage("Choose your fee receipt or admission letter first.", "error");
    return;
  }
  if (file.size > 10 * 1024 * 1024 || !["application/pdf", "image/png", "image/jpeg"].includes(file.type)) {
    showMessage("Choose a PDF, PNG, or JPG file no larger than 10 MB.", "error");
    return;
  }

  submitApplicationButton.disabled = true;
  submitApplicationButton.textContent = "Submitting…";
  try {
    await api("/api/applications", { method: "POST", body: formData });
    applicationForm.reset();
    await refreshApplications();
    showMessage("Application submitted. You can follow its status below.");
  } catch (error) {
    showMessage(`Application could not be submitted: ${error.message}`, "error", true);
  } finally {
    submitApplicationButton.disabled = false;
    submitApplicationButton.textContent = "Submit application";
  }
});

logoutButton.addEventListener("click", async () => {
  try {
    await api("/api/auth/logout", { method: "POST" });
    setSignedIn(null);
    showMessage("You have logged out.");
  } catch (error) {
    showMessage(`Could not log out: ${error.message}`, "error", true);
  }
});

api("/api/auth/me")
  .then(({ user }) => {
    if (user && user.role !== "student") {
      showMessage("This account is for the warden portal. Log out there before using student access.", "error", true);
      return api("/api/auth/logout", { method: "POST" });
    }
    setSignedIn(user);
  })
  .catch((error) => showMessage(`Could not connect to the prototype server: ${error.message}`, "error", true));
